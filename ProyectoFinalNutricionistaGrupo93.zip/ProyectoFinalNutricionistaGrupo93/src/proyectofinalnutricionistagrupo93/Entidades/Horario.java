package proyectofinalnutricionistagrupo93.Entidades;

public enum Horario {
    DESAYUNO,
    ALMUERZO,
    MERIENDA,
    CENA,
    SNACK
}
